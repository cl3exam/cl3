package com.examples.akshay.trigocal;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	
	ArrayList<String> arrayList = new ArrayList<>();
    String string = "";

    public void onClick(View v)
    {
        TextView textView = findViewById(R.id.textView);
        EditText editText = findViewById(R.id.editText);

        string = editText.getText().toString();
        String string2;
        switch (v.getId())
        {
            case R.id.button1:
                    arrayList.add(string);
                    arrayList.add("-");
                    string="";
                    editText.setText("");
                break;

            case R.id.button2:
                arrayList.add(string);
                arrayList.add("+");
                string="";
                editText.setText("");
                break;

            case R.id.button3:
                arrayList.add(string);
                arrayList.add("*");
                string="";
                editText.setText("");
                break;

            case R.id.button4:
                arrayList.add(string);
                arrayList.add("/");
                string="";
                editText.setText("");
                break;

            case R.id.buttonsin:
                arrayList.add("Sin");
                editText.setText("");
                break;

            case R.id.buttoncos:
                arrayList.add("Cos");
                editText.setText("");
                break;

            case R.id.buttontan:
                arrayList.add("Tan");
                editText.setText("");
                break;
        }
        string2 = arrayList.toString().replace(",", "")  //remove the commas
            .replace("[", "")  //remove the right bracket
            .replace("]", "")  //remove the left bracket
            .trim();
        textView.setText(string2);
    }

    String file = "Calculations";

    public void onEqual (View v)
    {
        TextView textView = findViewById(R.id.textView);
        EditText editText = findViewById(R.id.editText);
        string =  editText.getText().toString();
        arrayList.add(string);
        double calc = 0;
        int c=arrayList.size();
        String string2 = arrayList.toString().replace(",", "")  //remove the commas
                .replace("[", "")  //remove the right bracket
                .replace("]", "")  //remove the left bracket
                .trim();
        while(c!=1)
        {
            if(c==2)
            {
                if(arrayList.get(0).contains("Sin")) {calc = Math.sin(Double.parseDouble(arrayList.get(1)));}
                if(arrayList.get(0).contains("Cos")) {calc = Math.cos(Double.parseDouble(arrayList.get(1)));}
                if(arrayList.get(0).contains("Tan")) {calc = Math.tan(Double.parseDouble(arrayList.get(1)));}
                arrayList.remove(0);
                arrayList.remove(0);
                arrayList.add(0, Double.toString(calc));
                c = arrayList.size();
            }
            else if(c == 3)
            {
                if(arrayList.get(1).contains("+")) {calc = Double.parseDouble(arrayList.get(0)) + Double.parseDouble(arrayList.get(2));}
                if(arrayList.get(1).contains("-")) {calc = Double.parseDouble(arrayList.get(0)) - Double.parseDouble(arrayList.get(2));}
                if(arrayList.get(1).contains("*")) {calc = Double.parseDouble(arrayList.get(0)) * Double.parseDouble(arrayList.get(2));}
                if(arrayList.get(1).contains("/")) {calc = Double.parseDouble(arrayList.get(0)) / Double.parseDouble(arrayList.get(2));}
                arrayList.remove(0);
                arrayList.remove(0);
                arrayList.remove(0);
                arrayList.add(0, Double.toString(calc));
                c = arrayList.size();
            }
            else {
                for (int i = 0; i < c; i++) {
                    if (arrayList.get(i).contains("Sin")) {
                        calc = Math.sin(Double.parseDouble(arrayList.get(i + 1)));
                        arrayList.remove(i);
                        arrayList.remove(i);
                        arrayList.add(i, Double.toString(calc));
                        c = arrayList.size();
                    }
                    if (arrayList.get(i).contains("Cos")) {
                        calc = Math.cos(Double.parseDouble(arrayList.get(i + 1)));
                        arrayList.remove(i);
                        arrayList.remove(i);
                        arrayList.add(i, Double.toString(calc));
                        c = arrayList.size();
                    }
                    if (arrayList.get(i).contains("Tan")) {
                        calc = Math.tan(Double.parseDouble(arrayList.get(i + 1)));
                        arrayList.remove(i);
                        arrayList.remove(i);
                        arrayList.add(i, Double.toString(calc));
                        c = arrayList.size();
                    }
                }
                if (c > 3) {
                    if (arrayList.get(3).contains("*") || arrayList.get(3).contains("/")) {
                        if (arrayList.get(3).contains("*")) {
                            calc = Double.parseDouble(arrayList.get(2)) * Double.parseDouble(arrayList.get(4));
                        }
                        if (arrayList.get(3).contains("/")) {
                            calc = Double.parseDouble(arrayList.get(2)) / Double.parseDouble(arrayList.get(4));
                        }
                        arrayList.remove(2);
                        arrayList.remove(2);
                        arrayList.remove(2);
                        arrayList.add(2, Double.toString(calc));
                        c = arrayList.size();
                    } else {
                        if (arrayList.get(1).contains("+")) {
                            calc = Double.parseDouble(arrayList.get(0)) + Double.parseDouble(arrayList.get(2));
                        }
                        if (arrayList.get(1).contains("-")) {
                            calc = Double.parseDouble(arrayList.get(0)) - Double.parseDouble(arrayList.get(2));
                        }
                        if (arrayList.get(1).contains("*")) {
                            calc = Double.parseDouble(arrayList.get(0)) * Double.parseDouble(arrayList.get(2));
                        }
                        if (arrayList.get(1).contains("/")) {
                            calc = Double.parseDouble(arrayList.get(0)) / Double.parseDouble(arrayList.get(2));
                        }
                        arrayList.remove(0);
                        arrayList.remove(0);
                        arrayList.remove(0);
                        arrayList.add(0, Double.toString(calc));
                        c = arrayList.size();
                    }
                }
            }
        }
        string2 = string2 + "=" + Double.toString(calc);
        textView.setText(string2);
        editText.setText("");
        try{
            FileOutputStream fout= openFileOutput(file,MODE_APPEND);
            fout.write(string2.getBytes());
            fout.close();
            String filepath = String.valueOf(getFileStreamPath(file));
            Toast.makeText(getBaseContext(),"Noted in "+filepath,Toast.LENGTH_SHORT).show();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        arrayList.clear();
    }

    public void onShow(View v)
    {
        TextView textView = findViewById(R.id.textView);
        try{
            FileInputStream fin = openFileInput(file);
            int c;
            String temp ="";

            while((c = fin.read()) != -1) {
                temp = temp + Character.toString((char) c);
                textView.setText(temp);
            }
        }
        catch(Exception e)
        {e.printStackTrace();}
    }

    public void onClear(View v)
    {
        try{
            FileOutputStream fout= openFileOutput(file,MODE_WORLD_READABLE);
            fout.write(0);
            fout.close();
            Toast.makeText(getBaseContext(),"File Cleared",Toast.LENGTH_SHORT).show();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

}
